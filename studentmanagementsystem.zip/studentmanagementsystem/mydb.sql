-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 19, 2024 at 09:44 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `ID` int(11) NOT NULL,
  `FNAME` varchar(50) DEFAULT NULL,
  `LNAME` varchar(50) DEFAULT NULL,
  `REGN` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`ID`, `FNAME`, `LNAME`, `REGN`) VALUES
(1, 'TUYIZERE', 'Aimable', '22rp02692'),
(2, 'qwert', 'aimabl111', '22rp02691'),
(3, 'NIYOMUKIZA', 'ISMAEL', '22RP0278'),
(4, 'IGIHOZO', 'RACL', '23RP02692'),
(5, 'JOHN', 'KWIZERA', '22RP0789'),
(6, 'NIYOMUKIZA', 'ISMAEL', '22RP02691');

-- --------------------------------------------------------

--
-- Table structure for table `studentsmgmnt`
--

CREATE TABLE `studentsmgmnt` (
  `name` varchar(10) DEFAULT NULL,
  `regno` varchar(20) DEFAULT NULL,
  `math` int(11) DEFAULT NULL,
  `java` int(11) DEFAULT NULL,
  `php` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `studentsmgmnt`
--

INSERT INTO `studentsmgmnt` (`name`, `regno`, `math`, `java`, `php`) VALUES
('jkfdjkfd', '2222', 12, 23, 22),
('ismael', '22rp02692', 69, 69, 69),
('tuyizere', '22RP0268', 69, 90, 68),
('RRR', '34', 46, 45, 56),
('ttt', '45', 54, 45, 78),
('Rosette', '22RP01965', 35, 35, 35),
('JOHN', '22RP', 68, 89, 90),
('EEE', 'RR', 4, 4, 4),
('er', '34', 34, 56, 78),
('22RP02696', '22RP02696', 39, 90, 78);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `students`
--
ALTER TABLE `students`
  ADD PRIMARY KEY (`ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `students`
--
ALTER TABLE `students`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
